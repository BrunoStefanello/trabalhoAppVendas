package com.example.trabalhoappvendas;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CadastrarCliente extends AppCompatActivity {

    private EditText edNomeCliente, edCpfCliente;
    private Button btCadastrarCliente;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cadastrar_cliente);

        edNomeCliente = findViewById(R.id.edNomeCliente);
        edCpfCliente = findViewById(R.id.edCpfCliente);
        btCadastrarCliente = findViewById(R.id.btCadastrarCliente);

        btCadastrarCliente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = edNomeCliente.getText().toString();
                String cpf = edCpfCliente.getText().toString();

                if (nome.isEmpty() || cpf.isEmpty()) {
                    Toast.makeText(CadastrarCliente.this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                } else {
                    // Faça a lógica de cadastro do cliente aqui
                    // Você pode usar um banco de dados ou outra forma de armazenamento
                    Toast.makeText(CadastrarCliente.this, "Cliente cadastrado com sucesso", Toast.LENGTH_SHORT).show();

                    // Limpar os campos após o cadastro
                    edNomeCliente.setText("");
                    edCpfCliente.setText("");
                }
            }
        });
    }

}
