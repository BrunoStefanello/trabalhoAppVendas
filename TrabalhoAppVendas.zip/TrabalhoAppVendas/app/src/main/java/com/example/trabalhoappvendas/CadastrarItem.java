package com.example.trabalhoappvendas;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CadastrarItem extends AppCompatActivity {

    private EditText edCodigoItem;
    private EditText edDescricaoItem;
    private EditText edValorItem;
    private Button btCadastrarItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cadastrar_item);

        edCodigoItem = findViewById(R.id.edCodigoItem);
        edDescricaoItem = findViewById(R.id.edDescricaoItem);
        edValorItem = findViewById(R.id.edValorItem);
        btCadastrarItem = findViewById(R.id.btCadastrarItem);

        btCadastrarItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String codigo = edCodigoItem.getText().toString();
                String descricao = edDescricaoItem.getText().toString();
                String valorTexto = edValorItem.getText().toString();

                if (codigo.isEmpty() || descricao.isEmpty() || valorTexto.isEmpty()) {
                    Toast.makeText(CadastrarItem.this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                } else {

                    try {
                        double valor = Double.parseDouble(valorTexto);


                        edCodigoItem.setText("");
                        edDescricaoItem.setText("");
                        edValorItem.setText("");

                        Toast.makeText(CadastrarItem.this, "Item cadastrado com sucesso", Toast.LENGTH_SHORT).show();
                    } catch (NumberFormatException e) {
                        Toast.makeText(CadastrarItem.this, "Valor inválido", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}