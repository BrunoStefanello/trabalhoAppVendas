package com.example.trabalhoappvendas;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class LancarPedido extends AppCompatActivity {

    private Spinner spinnerCliente;
    private Spinner spinnerItemVenda;
    private EditText editTextQuantidade;
    private EditText editTextValorUnitario;
    private Button btnAdicionarItem;
    private ListView listViewItensPedido;
    private TextView textViewValorTotal;
    private Spinner spinnerCondicaoPagamento;
    private EditText editTextQuantidadeParcelas;
    private ListView listViewParcelas;
    private Button btnConcluirPedido;

    private List<ItemPedido> listaItensPedido = new ArrayList<>();
    private ArrayAdapter<ItemPedido> adapterItensPedido;
    private double valorTotal = 0.0;
    private List<String> itensVenda; // Correção: Declare uma lista para itens de venda
    private List<String> condicoesPagamento; // Correção: Declare uma lista para condições de pagamento

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lancar_pedido);

        spinnerCliente = findViewById(R.id.spinnerCliente);
        spinnerItemVenda = findViewById(R.id.spinnerItemVenda);
        editTextQuantidade = findViewById(R.id.editTextQuantidade);
        editTextValorUnitario = findViewById(R.id.editTextValorUnitario);
        btnAdicionarItem = findViewById(R.id.btnAdicionarItem);
        listViewItensPedido = findViewById(R.id.listViewItensPedido);
        textViewValorTotal = findViewById(R.id.textViewValorTotal);
        spinnerCondicaoPagamento = findViewById(R.id.spinnerCondicaoPagamento);
        editTextQuantidadeParcelas = findViewById(R.id.editTextQuantidadeParcelas);
        listViewParcelas = findViewById(R.id.listViewParcelas);
        btnConcluirPedido = findViewById(R.id.btnConcluirPedido);

        // Inicialize as listas de itens de venda e condições de pagamento
        itensVenda = getItensVenda(); // Chame o método que retorna os itens de venda
        condicoesPagamento = getCondicoesPagamento(); // Chame o método que retorna as condições de pagamento

        ArrayAdapter<String> clienteAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, getClientes());
        clienteAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCliente.setAdapter(clienteAdapter);

        ArrayAdapter<String> itemAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, itensVenda);
        itemAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerItemVenda.setAdapter(itemAdapter);

        ArrayAdapter<String> condicaoPagamentoAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, condicoesPagamento);
        condicaoPagamentoAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCondicaoPagamento.setAdapter(condicaoPagamentoAdapter);

        adapterItensPedido = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listaItensPedido);
        listViewItensPedido.setAdapter(adapterItensPedido);

        btnAdicionarItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String itemSelecionado = spinnerItemVenda.getSelectedItem().toString();
                double quantidade = Double.parseDouble(editTextQuantidade.getText().toString());
                double valorUnitario = Double.parseDouble(editTextValorUnitario.getText().toString());

                // Crie um novo ItemPedido e adicione-o à lista
                ItemPedido novoItem = new ItemPedido(itemSelecionado, quantidade, valorUnitario);
                listaItensPedido.add(novoItem);

                // Atualize o adaptador da lista de itens e calcule o novo valor total
                adapterItensPedido.notifyDataSetChanged();
                valorTotal += quantidade * valorUnitario;
                textViewValorTotal.setText("Valor Total: R$ " + String.format("%.2f", valorTotal));
            }
        });
    }

    private List<String> getClientes() {
        // Implemente este método para retornar uma lista de clientes
        List<String> clientes = new ArrayList<>();
        clientes.add("Cliente 1");
        clientes.add("Cliente 2");
        // Adicione mais clientes conforme necessário
        return clientes;
    }

    private List<String> getItensVenda() {
        // Implemente este método para retornar uma lista de itens de venda
        List<String> itens = new ArrayList<>();
        itens.add("Item 1");
        itens.add("Item 2");
        // Adicione mais itens conforme necessário
        return itens;
    }

    private List<String> getCondicoesPagamento() {
        // Implemente este método para retornar uma lista de condições de pagamento
        List<String> condicoes = new ArrayList<>();
        condicoes.add("À vista");
        condicoes.add("A prazo");
        // Adicione mais condições conforme necessário
        return condicoes;
    }

    private class ItemPedido {
        private String descricao;
        private double quantidade;
        private double valorUnitario;

        public ItemPedido(String descricao, double quantidade, double valorUnitario) {
            this.descricao = descricao;
            this.quantidade = quantidade;
            this.valorUnitario = valorUnitario;
        }

        @Override
        public String toString() {
            return descricao + " - Qtd: " + quantidade + " - Valor Unitário: R$ " + String.format("%.2f", valorUnitario);
        }
    }
}